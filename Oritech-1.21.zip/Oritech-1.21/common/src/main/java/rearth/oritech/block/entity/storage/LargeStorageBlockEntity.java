package rearth.oritech.block.entity.storage;

import rearth.oritech.init.OritechConfig;
import rearth.oritech.Oritech;
import rearth.oritech.block.base.entity.ExpandableMultiblockEnergyStorageBlockEntity;
import rearth.oritech.block.entity.addons.RedstoneAddonBlockEntity;
import rearth.oritech.init.BlockEntitiesContent;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.world.level.block.state.BlockState;

public class LargeStorageBlockEntity extends ExpandableMultiblockEnergyStorageBlockEntity implements RedstoneAddonBlockEntity.RedstoneControllable {
    
    public LargeStorageBlockEntity(BlockPos pos, BlockState state) {
        super(BlockEntitiesContent.LARGE_STORAGE_ENTITY, pos, state);
    }
    
    @Override
    public List<Vec3i> getAddonSlots() {
        return List.of(
          new Vec3i(0, 0,-1),
          new Vec3i(0, 0,1),
          new Vec3i(0, 1,-1),
          new Vec3i(0, 1,1),
          new Vec3i(1, 0,-1),
          new Vec3i(1, 0,1),
          new Vec3i(1, 1,-1),
          new Vec3i(1, 1,1)
        );
    }
    
    @Override
    public long getDefaultCapacity() {
        return OritechConfig.largeEnergyStorage.energyCapacity.get();
    }
    
    @Override
    public long getDefaultInsertRate() {
        return OritechConfig.largeEnergyStorage.maxEnergyInsertion.get();
    }
    
    @Override
    public long getDefaultExtractionRate() {
        return OritechConfig.largeEnergyStorage.maxEnergyExtraction.get();
    }
    
    @Override
    public List<Vec3i> getCorePositions() {
        return List.of(
          new Vec3i(0, 1,0),
          new Vec3i(1, 0,0),
          new Vec3i(1, 1,0)
        );
    }
    
    @Override
    public int getComparatorEnergyAmount() {
        if (energyStorage.amount == 0) return 0;
        return (int) (1 + ((energyStorage.amount / (float) energyStorage.capacity) * 14));
    }
    
    @Override
    public int getComparatorSlotAmount(int slot) {
        if (inventory.heldStacks.size() <= slot) return 0;
        
        var stack = inventory.getItem(slot);
        if (stack.isEmpty()) return 0;
        
        return (int) (1 + (stack.getCount() / (float) stack.getMaxStackSize()) * 15);
    }
    
    @Override
    public int getComparatorProgress() {
        return 0;
    }
    
    @Override
    public int getComparatorActiveState() {
        return 15;
    }
    
    @Override
    public void onRedstoneEvent(boolean isPowered) {
        this.setRedstonePowered(isPowered);
    }
    
}
