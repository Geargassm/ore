package rearth.oritech.api.energy.containers;

import io.netty.buffer.ByteBuf;
import rearth.oritech.compat.ByteBufCodecs;
import rearth.oritech.compat.StreamCodec;
import rearth.oritech.api.energy.EnergyApi;
import rearth.oritech.api.networking.SyncType;
import rearth.oritech.api.networking.UpdatableField;

public class SimpleEnergyStorage extends EnergyApi.EnergyStorage implements UpdatableField<Void, Long> {
    private final long maxInsert;
    private final long maxExtract;
    private final long capacity;
    private final Runnable onUpdate;
    
    private long amount;
    
    public SimpleEnergyStorage(long maxInsert, long maxExtract, long capacity, Runnable onUpdate) {
        this.maxInsert = maxInsert;
        this.maxExtract = maxExtract;
        this.capacity = capacity;
        this.onUpdate = onUpdate;
    }
    
    public SimpleEnergyStorage(long maxInsert, long maxExtract, long capacity) {
        this.maxInsert = maxInsert;
        this.maxExtract = maxExtract;
        this.capacity = capacity;
        this.onUpdate = () -> {};
    }
    
    @Override
    public long insert(long amount, boolean simulate) {
        long inserted = Math.min(Math.min(maxInsert, amount), capacity - this.amount);
        if (!simulate) {
            this.amount += inserted;
        }
        return inserted;
    }
    
    public long insertIgnoringLimit(long amount, boolean simulate) {
        long inserted = Math.min(amount, capacity - this.amount);
        if (!simulate) {
            this.amount += inserted;
        }
        return inserted;
    }
    
    @Override
    public long extract(long amount, boolean simulate) {
        long extracted = Math.min(Math.min(amount, maxExtract), this.amount);
        if (!simulate) {
            this.amount -= extracted;
        }
        return extracted;
    }
    
    public long extractIgnoringLimit(long amount, boolean simulate) {
        long extracted = Math.min(amount, this.amount);
        if (!simulate) {
            this.amount -= extracted;
        }
        return extracted;
    }
    
    @Override
    public void setAmount(long amount) {
        this.amount = amount;
    }
    
    @Override
    public long getAmount() {
        return amount;
    }
    
    @Override
    public long getCapacity() {
        return capacity;
    }
    
    @Override
    public void update() {
        onUpdate.run();
    }
    
    @Override
    public Long getDeltaData() {
        return amount;
    }
    
    @Override
    public Void getFullData() {
        return null;
    }
    
    @Override
    public boolean useDeltaOnly(SyncType type) {
        return true;
    }
    
    @Override
    public StreamCodec<? extends ByteBuf, Long> getDeltaCodec() {
        return ByteBufCodecs.VAR_LONG;
    }
    
    @Override
    public StreamCodec<? extends ByteBuf, Void> getFullCodec() {
        return null;
    }
    
    @Override
    public void handleFullUpdate(Void updatedData) {
    
    }
    
    @Override
    public void handleDeltaUpdate(Long updatedData) {
        this.amount = updatedData;
    }
}