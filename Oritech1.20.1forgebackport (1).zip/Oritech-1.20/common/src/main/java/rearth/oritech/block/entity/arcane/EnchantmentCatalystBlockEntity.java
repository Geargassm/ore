package rearth.oritech.block.entity.arcane;
import rearth.oritech.api.networking.PacketId;

import dev.architectury.registry.menu.ExtendedMenuProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.nbt.ListTag;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import rearth.oritech.Oritech;
import rearth.oritech.api.energy.EnergyApi;
import rearth.oritech.api.energy.containers.SimpleEnergyStorage;
import rearth.oritech.api.item.ItemApi;
import rearth.oritech.api.item.containers.SimpleInventoryStorage;
import rearth.oritech.api.networking.NetworkManager;
import rearth.oritech.client.init.ModScreens;
import rearth.oritech.client.init.ParticleContent;
import rearth.oritech.client.ui.CatalystScreenHandler;
import rearth.oritech.init.BlockEntitiesContent;
import rearth.oritech.init.OritechConfig;
import rearth.oritech.init.TagContent;
import rearth.oritech.util.AutoPlayingSoundKeyframeHandler;
import rearth.oritech.util.ComparatorOutputProvider;
import rearth.oritech.util.InventoryInputMode;
import rearth.oritech.util.ScreenProvider;
import software.bernie.geckolib.animatable.GeoBlockEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.List;

public class EnchantmentCatalystBlockEntity extends BaseSoulCollectionEntity
  implements ItemApi.BlockProvider, EnergyApi.BlockProvider, ScreenProvider, ComparatorOutputProvider, GeoBlockEntity, BlockEntityTicker<EnchantmentCatalystBlockEntity>, ExtendedMenuProvider {
    
    public static final RawAnimation IDLE = RawAnimation.begin().thenLoop("idle");
    public static final RawAnimation STABILIZED = RawAnimation.begin().thenLoop("stabilized");
    public static final RawAnimation UNSTABLE = RawAnimation.begin().thenLoop("unstable");
    public static final RawAnimation EMPTY = RawAnimation.begin().thenLoop("empty");
    
    public final int baseSoulCapacity = OritechConfig.catalystBaseSouls.get();
    public final int maxProgress = 20;
    protected final AnimatableInstanceCache animatableInstanceCache = GeckoLibUtil.createInstanceCache(this);
    
    // working data
    public int collectedSouls;
    public int maxSouls = OritechConfig.catalystBaseSouls.get();
    private int unstableTicks;
    private int progress;
    private boolean isHyperEnchanting;
    private boolean networkDirty;
    private String lastAnimation = "invalid";
    private int lastComparatorOutput;
    
    public final SimpleInventoryStorage inventory = new SimpleInventoryStorage(2, this::setChanged) {
        @Override
        public int insertToSlot(ItemStack addedStack, int slot, boolean simulate) {
            if (slot == 0 && !addedStack.isEmpty() && !addedStack.getItem().equals(Items.ENCHANTED_BOOK)) return 0; // only allow enchanter books in slot 0
            return super.insertToSlot(addedStack, slot, simulate);
        }
    };
    
    public final SimpleEnergyStorage energyStorage = new SimpleEnergyStorage(10_000, 0, 50_000);
    
    public EnchantmentCatalystBlockEntity(BlockPos pos, BlockState state) {
        super(BlockEntitiesContent.ENCHANTMENT_CATALYST_BLOCK_ENTITY, pos, state);
    }
    
    @Override
    public void tick(Level world, BlockPos pos, BlockState state, EnchantmentCatalystBlockEntity blockEntity) {
        
        if (world.isClientSide) return;
        
        // check if powered, and adjust soul capacity
        if (energyStorage.getAmount() > 0) {
            var gainedSoulCapacity = energyStorage.getAmount() / OritechConfig.catalystRFPerSoul.get();
            energyStorage.setAmount(0);
            var newMax = baseSoulCapacity + gainedSoulCapacity;
            adjustMaxSouls(newMax);
            this.setChanged();
        } else if (maxSouls > baseSoulCapacity) {
            adjustMaxSouls(baseSoulCapacity);
        }
        
        // explode if unstable
        if (collectedSouls > maxSouls) {
            unstableTicks++;
            
            if (world instanceof ServerLevel sl) { var c = pos.getCenter(); sl.sendParticles(ParticleTypes.LAVA, c.x, c.y, c.z, unstableTicks / 4, 1, 1, 1, 0); }
            
            if (unstableTicks > 60)
                doExplosion();
            return;
        }
        
        unstableTicks = 0;
        
        // check if output is empty
        // check if a book is in slot 0
        // check if an item is in slot 1
        if (canProceed()) {
            networkDirty = true;
            progress++;
            
            if (world instanceof ServerLevel sl) { var c = pos.getCenter().add(0, 0.3, 0); sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, c.x, c.y, c.z, isHyperEnchanting ? 15 : 3, 1.2, 1.2, 1.2, 0); }
            
            if (progress >= maxProgress) {
                enchantInput();
                if (world instanceof ServerLevel sl) { var c = pos.getCenter(); sl.sendParticles(ParticleTypes.ENCHANTED_HIT, c.x, c.y, c.z, maxProgress + 10, 0.6, 0.6, 0.6, 0); }
                
                progress = 0;
                isHyperEnchanting = false;
            }
        } else {
            progress = 0;
        }
        
        if (networkDirty) {
            networkDirty = false;
            updateNetwork();
            DeathListener.resetEvents();
            updateAnimation();
            
            var level = calculateComparatorLevel();
            if (level != lastComparatorOutput) {
                lastComparatorOutput = level;
                world.updateNeighbourForOutputSignal(pos, state.getBlock());
            }
            
        }
        
        // periodically re-trigger animation updates
        if (world.getGameTime() % 60 == 0) {
            lastAnimation = "invalid";
            updateAnimation();
        }
        
    }
    
    private boolean isEmpty() {
        return collectedSouls <= 0;
    }
    
    @Override
    protected void saveAdditional(CompoundTag nbt) {
        super.saveAdditional(nbt);
        ContainerHelper.saveAllItems(nbt, inventory.heldStacks, false);
        nbt.putInt("souls", collectedSouls);
        nbt.putInt("maxSouls", maxSouls);
    }
    
    @Override
    protected void loadAdditional(CompoundTag nbt) {
        super.loadAdditional(nbt);
        ContainerHelper.loadAllItems(nbt, inventory.heldStacks);
        collectedSouls = nbt.getInt("souls");
        maxSouls = nbt.getInt("maxSouls");
    }
    
    public void doExplosion() {
        
        var center = worldPosition.getCenter();
        var strength = Math.sqrt(collectedSouls - baseSoulCapacity);
        
        level.explode(null, center.x, center.y, center.z, (int) strength, true, Level.ExplosionInteraction.BLOCK);
        level.removeBlock(worldPosition, false);
    }
    
    private void adjustMaxSouls(long target) {
        if (maxSouls > target) {
            maxSouls--;
        } else if (maxSouls < target) {
            maxSouls++;
        }
        
        this.networkDirty = true;
        this.setChanged();
    }
    
    private void enchantInput() {

        var bookCandidate = inventory.getItem(0);
        var storedEnchants = getStoredEnchantmentsFromBook(bookCandidate);
        if (storedEnchants == null || storedEnchants.isEmpty()) return;

        var firstEnchantTag = storedEnchants.getCompound(0);
        var enchantHolder = getEnchantmentHolderFromTag(firstEnchantTag);
        if (enchantHolder == null) return;

        var inputStack = inventory.getItem(1);
        var toolLevel = EnchantmentHelper.getItemEnchantmentLevel(enchantHolder.value(), inputStack);
        inputStack.enchant(enchantHolder.value(), toolLevel + 1);

        collectedSouls -= getEnchantmentCost(enchantHolder.value(), toolLevel + 1, isHyperEnchanting);

        if (isHyperEnchanting)
            inventory.setItem(0, ItemStack.EMPTY);

    }

    /** Returns the StoredEnchantments NBT list from an enchanted book, or null if not applicable. */
    @Nullable
    private ListTag getStoredEnchantmentsFromBook(ItemStack bookStack) {
        if (!bookStack.getItem().equals(Items.ENCHANTED_BOOK)) return null;
        var storedEnchants = EnchantedBookItem.getEnchantments(bookStack);
        return storedEnchants.isEmpty() ? null : storedEnchants;
    }

    @Nullable
    private net.minecraft.core.Holder<Enchantment> getEnchantmentHolderFromTag(net.minecraft.nbt.CompoundTag enchantTag) {
        if (level == null) return null;
        var id = enchantTag.getString("id");
        var registry = level.registryAccess().registryOrThrow(net.minecraft.core.registries.Registries.ENCHANTMENT);
        var loc = net.minecraft.resources.ResourceLocation.tryParse(id);
        if (loc == null) return null;
        var enchant = registry.get(loc);
        return enchant != null ? registry.wrapAsHolder(enchant) : null;
    }
    
    private boolean hasEnoughSouls(Enchantment enchantment, int targetLevel) {
        var resultingCost = getEnchantmentCost(enchantment, targetLevel, isHyperEnchanting);
        return collectedSouls >= resultingCost;
    }
    
    private int getEnchantmentCost(Enchantment enchantment, int targetLevel, boolean hyper) {
        var baseCost = enchantment.getAnvilCost();
        var resultingCost = baseCost * targetLevel * OritechConfig.catalystCostMultiplier.get();
        if (hyper) resultingCost = (int) (Math.pow(resultingCost * OritechConfig.catalystHyperMultiplier.get(), OritechConfig.catalystHyperExpFactor.get()) + OritechConfig.catalystBaseSouls.get());
        return resultingCost;
    }
    
    // for UI
    public int getDisplayedCost() {
        if (inventory.getItem(0).isEmpty() || inventory.getItem(1).isEmpty()) return 0;
        var bookCandidate = inventory.getItem(0);

        var storedEnchants = getStoredEnchantmentsFromBook(bookCandidate);
        if (storedEnchants != null && !storedEnchants.isEmpty()) {
            var firstEnchantTag = storedEnchants.getCompound(0);
            var enchantHolder = getEnchantmentHolderFromTag(firstEnchantTag);
            if (enchantHolder == null) return 0;

            var maxLevel = enchantHolder.value().getMaxLevel();
            var bookLevel = firstEnchantTag.getShort("lvl");

            if (bookLevel != maxLevel) return 0;

            var inputStack = inventory.getItem(1);
            var toolLevel = EnchantmentHelper.getItemEnchantmentLevel(enchantHolder.value(), inputStack);
            var isHyper = toolLevel >= maxLevel;

            return getEnchantmentCost(enchantHolder.value(), toolLevel + 1, isHyper);
        }

        return 0;
    }
    
    private boolean canProceed() {

        if (inventory.getItem(0).isEmpty() || inventory.getItem(1).isEmpty()) return false;

        var bookCandidate = inventory.getItem(0);
        var storedEnchants = getStoredEnchantmentsFromBook(bookCandidate);
        if (storedEnchants != null && !storedEnchants.isEmpty()) {
            var firstEnchantTag = storedEnchants.getCompound(0);
            var enchantHolder = getEnchantmentHolderFromTag(firstEnchantTag);
            if (enchantHolder == null) return false;

            var maxLevel = enchantHolder.value().getMaxLevel();
            var bookLevel = firstEnchantTag.getShort("lvl");

            if (enchantHolder.is(TagContent.CATALYST_ENCHANTMENT_BLACKLIST)) return false;

            // yes this does not check if the item can be enchanted with this enchantment. This is intentional
            var inputStack = inventory.getItem(1);
            var toolLevel = EnchantmentHelper.getItemEnchantmentLevel(enchantHolder.value(), inputStack);
            this.isHyperEnchanting = toolLevel >= maxLevel;

            return bookLevel == maxLevel && hasEnoughSouls(enchantHolder.value(), toolLevel + 1);
        }

        return false;
    }
    
    @Override
    public void onSoulIncoming(Vec3 source) {
        var distance = (float) source.distanceTo(worldPosition.getCenter());
        collectedSouls++;
        networkDirty = true;
        this.setChanged();
        
        var soulPath = worldPosition.getCenter().subtract(source);
        ParticleContent.WanderingSoul(level, source.add(0, 0.7f, 0), soulPath, (int) getSoulTravelDuration(distance));
    }
    
    @Override
    public boolean canAcceptSoul() {
        return collectedSouls < maxSouls;
    }

    @Override
    public int getComparatorOutput() {
        return calculateComparatorLevel();
    }
    
    private int calculateComparatorLevel() {
        return (int) ((float) collectedSouls / maxSouls * 16);
    }
    
    private void updateNetwork() {
        NetworkManager.sendBlockHandle(this, new CatalystSyncPacket(worldPosition, collectedSouls, progress, isHyperEnchanting, maxSouls));
    }
    
    @Override
    public void saveExtraData(FriendlyByteBuf buf) {
        buf.writeBlockPos(worldPosition);
    }
    
    @Override
    public Component getDisplayName() {
        return Component.literal("");
    }
    
    @Override
    public boolean showProgress() {
        return false;
    }
    
    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int syncId, Inventory playerInventory, Player player) {
        updateNetwork();
        return new CatalystScreenHandler(syncId, playerInventory, this);
    }
    
    @Override
    public ItemApi.InventoryStorage getInventoryStorage(Direction direction) {
        return inventory;
    }
    
    @Override
    public EnergyApi.EnergyStorage getEnergyStorage(Direction direction) {
        return energyStorage;
    }
    
    @Override
    public List<GuiSlot> getGuiSlots() {
        return List.of(
          new GuiSlot(0, 56, 35),
          new GuiSlot(1, 75, 35));
    }
    
    @Override
    public BarConfiguration getEnergyConfiguration() {
        return new BarConfiguration(8, 7, 18, 71);
    }
    
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "machine", 4, state -> {
            if (state.getController().getAnimationState().equals(AnimationController.State.STOPPED))
                return state.setAndContinue(EMPTY);
            return PlayState.CONTINUE;
        })
                          .triggerableAnim("stabilized", STABILIZED)
                          .triggerableAnim("idle", IDLE)
                          .triggerableAnim("unstable", UNSTABLE)
                          .triggerableAnim("empty", EMPTY)
                          .setSoundKeyframeHandler(new AutoPlayingSoundKeyframeHandler<>()));
    }
    
    private void updateAnimation() {
        
        var targetAnim = isEmpty() ? "empty" : "idle";
        if (maxSouls > baseSoulCapacity)
            targetAnim = "stabilized";
        
        if (unstableTicks > 0)
            targetAnim = "unstable";
        
        if (!targetAnim.equals(lastAnimation)) {
            triggerAnim("machine", targetAnim);
            lastAnimation = targetAnim;
        }
        
    }
    
    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return animatableInstanceCache;
    }
    
    @Override
    public float getDisplayedEnergyUsage() {
        return 0;
    }
    
    @Override
    public float getProgress() {
        return progress / (float) maxProgress;
    }
    
    @Override
    public InventoryInputMode getInventoryInputMode() {
        return InventoryInputMode.FILL_LEFT_TO_RIGHT;
    }
    
    @Override
    public Container getDisplayedInventory() {
        return inventory;
    }
    
    @Override
    public MenuType<?> getScreenHandlerType() {
        return ModScreens.CATALYST_SCREEN;
    }
    
    @Override
    public boolean inputOptionsEnabled() {
        return false;
    }
    
    // this is used as soul display instead
    @Override
    public boolean showEnergy() {
        return true;
    }
    
    public static void receiveUpdatePacket(CatalystSyncPacket packet, Level world, Player player) {
        if (world.getBlockEntity(packet.position) instanceof EnchantmentCatalystBlockEntity catalystBlock) {
            catalystBlock.isHyperEnchanting = packet.isHyperEnchanting();
            catalystBlock.progress = packet.progress();
            catalystBlock.collectedSouls = packet.storedSouls();
            catalystBlock.maxSouls = packet.maxSouls();
        }
    }
    
    public record CatalystSyncPacket(BlockPos position, int storedSouls, int progress, boolean isHyperEnchanting, int maxSouls) {
        
        public static final PacketId<CatalystSyncPacket> PACKET_ID = new PacketId<>(Oritech.id("catalyst"));
        
    }
}
